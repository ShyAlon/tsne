function quality = quality(X, Y)
% Quality tests the dimentionality reduction quality
%
% It takes the results and calculates a score: 
% for each point if the nearest neighbour is of the same label it adds one
% and returns the ratio of those points
    quality = 0;
    [m,n] = size(X);
    for i = 1 : m
        nearest = inf;
        shortest = inf;
        for j = 1 : m
            if i ~= j
                dx = X(i,1) - X(j,1);
                dy = X(i,2) - X(j,2);
                distance = (dx^2 + dy^2)^.5;
                if distance < shortest
                    nearest = j;
                    shortest = distance;
                end 
            end
        end
        if iscellstr(Y)
            if strcmp(Y{i},Y{nearest})
                quality = quality +1;
            end
        else
            if Y(i) == Y(nearest)
                quality = quality +1;
            end
        end
    end
    quality = quality / m;
end
