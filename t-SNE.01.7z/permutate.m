function permutate = permutate(current, previous, currentScore, previousScore, maxFeatures, minFeatures)
% Permutate changes the feature selection based on the progression
% The options are feature deletion, feature addition and feature
% renumbering
    delta = 0;
    while delta == 0
        if currentScore > previousScore
            permutate = current
        else
            permutate = previous
        end

        % select a permutation
        action = rand;
        features = 0;

        for digit = 1:maxFeatures
            if bitand(permutate, 2^digit) > 0
                features = features + 1;
            end
        end

        temp = permutate;
        if action < 0.33
           % remove features 
            permutate = remove_features(maxFeatures, minFeatures, permutate, features);
        elseif action > 0.66
            % add features 
            permutate = add_features(maxFeatures, permutate, features);
        else
            % replace features 
            permutate = remove_features(maxFeatures, minFeatures, permutate, features);
            permutate = add_features(maxFeatures, permutate, features);
        end
        delta = temp - permutate
    end
end

function result = add_features(maxFeatures, permutate, features)
    result = permutate;
    for digit = 1:maxFeatures
        if bitand(permutate, 2^digit) == 0
            % 20% to light it up
            if and(rand < 0.5, features < maxFeatures)
                result = permutate + 2^digit;
                features = features + 1;
            end
        end
    end
end

function result = remove_features(maxFeatures, minFeatures, permutate, features)
    result = permutate;
    for digit = 1:maxFeatures
        if bitand(permutate, 2^digit) > 0
            % 20% to light it up
            if and(rand < 0.5, features > minFeatures)
                result = permutate - 2^digit;
                features = features - 1;
            end
        end
    end
end
