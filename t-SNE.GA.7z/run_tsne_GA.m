%% Define the data source
clear('all')
for trial = 2:6
    % filename = websave('mnist_train.mat', 'https://github.com/awni/cs224n-pa4/blob/master/Simple_tSNE/mnist_train.mat?raw=true');
    %% Financial Ratios
    if trial == 1
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\financialratios.data.csv';
        name = 'financialratios';
    elseif trial == 2     
    %% Qualitative bankruptcy
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\Qualitative_Bankruptcy.data.csv';
        name = 'Qualitative_Bankruptcy';
    elseif trial == 3  
    %% CMC Database
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\CMC_DataBase.csv';
        tags = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\CMC_DataBase_labels.csv';
        name = 'CMC';
    elseif trial == 4  
    %% Bitter Database
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\bitter_dataBase.csv';
        name = 'bitter';
    elseif trial == 5  
    %% Solar Cells Database
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\solar_cells_DataBase.csv';
        name = 'solar_cells';
    elseif trial == 6  
    %% LogBBB Database
        local = 'D:\DropBox\Dropbox\Avi_and_the_Gang\Shy\large_files\logbbb.csv';
        name = 'LogBBB';
    end

    %% Read the data source

    new = csvread(local);
    if trial == 3
        data = new(:, 1:end);
        fid = fopen(tags,'r');
        labels = textscan(fid, '%q');
        labels = cellstr( labels{1});
        fclose(fid);
    else
        data = new(:, 1:end-1);
        labels = new(:, end);
    end
    [m,n] = size(new)
    % labels = labels';

    %% Process the data
    h1 = figure;
    t = 6;
    p = 10;
    q = 0;
    old_q = -inf;
    old_t = 0;
    top_seed = 0;
    jumps = 0;
    iSeed = 1;
    iQuality = 2;
    iTrust = 3;
    population = []
    population_size = 20;
    
    % Create the seed population
    for sz = 1 : population_size % number of samples
        num = floor(rand * 2^n);
        [map, q, trust, features] = singletsne(new, num, n, labels);
        population(sz, iSeed) = num;
        population(sz, iQuality) = q;
        population(sz, iTrust) = trust;
    end
    % Sort the existing population
    population = sortrows(population, -iQuality);
    q_max = 0;
    for generations = 1 : 128
        % create the mutations
        for index = 1 : population_size * 0.2
            population(population_size + 1 - index, iSeed) = permutate(population(index, iSeed), n, 5);
        end
        % create the hybrids
        for index = population_size/2 : 2 : 2
            parent1 = population(population_size/2 + 1 - index, iSeed);
            parent2 = population(population_size/2 + 2 - index, iSeed);
            population(index + population_size*0.3, iSeed) = cross(parent1, parent2, n);
            population(index + population_size*0.3 -1, iSeed) = cross(parent2, parent1, n);
        end
        % calculate for the bottom 14
        inter_q = 0;
        inter_map = [];
        top_num = 0;
        for sz = population_size*0.3 + 1 : population_size % number of samples
            num = population(sz, iSeed);
            [map, q, trust, features] = singletsne(new, num, n, labels);
            population(sz, iSeed) = num;
            population(sz, iQuality) = q;
            population(sz, iTrust) = trust;
            if q > inter_q
                inter_q = q;
                inter_map = map;
                top_num = num;
            end
        end
        % Sort the existing population
        population = sortrows(population, -iQuality);
        
        legend('off');
        % Genetic algorithm implementation
        if inter_q > q_max  % there was improvement or overcoming local maximum        
            try
                q_max = inter_q;
                csvwrite(sprintf('results/%s_population_%0.3f.csv',name, generations), population);
                h = gscatter(map(:,1), map(:,2), labels); 
                xlabel('xlabel'),ylabel('ylabel')%(txt(i))
                csvwrite(sprintf('results/%s_population_%0.3f.csv',name, generations), population);
                filename = sprintf('results/%s_%0.3f_trustworthiness_%0.3f_number_%0.0f_features_%0.0f.png',name, q_max, trust, top_num, features);
                title(sprintf('%s %0.3f trustworthiness %0.3f number %0.0f features %0.0f.png',name, q_max, trust, top_num, features));
                saveas(h1, filename);
                csvwrite(sprintf('results/%s_quality_%0.3f_trustworthiness_%0.3f_number_%0.0f_features_%0.0f.csv',name, q_max, trust, top_num, features), map);
            catch ME
                disp('Failed writing the result files');
            end 
        end
    end   
end