function [dataForSeed, features] = dataForSeed(num, source, n)
% Permutate changes the feature selection based on the progression
% The options are feature deletion, feature addition and feature
% renumbering
    num = floor(rand * 2^n);
    dataForSeed = [];
    features = 0;
    % select the features based on the seed
    for digit = 1:n
        if bitand(num, 2^digit) > 0
            dataForSeed = horzcat(dataForSeed, source(:, digit));
            features = features + 1;
        end
    end
end
